PROYECTO REGENEDAR - Web oficial

Cómo publicar esta web:
1. Crea un repositorio público en GitHub llamado 'regenedar'.
2. Sube los archivos de este ZIP (index.html y la carpeta assets/).
3. Activa GitHub Pages en Settings → Pages → Branch 'main' → Folder '/ (root)'.
4. Tu web estará disponible en: https://tuusuario.github.io/regenedar/

Autor: Proyecto REGENEDAR - 2025
